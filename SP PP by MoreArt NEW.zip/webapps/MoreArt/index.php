<?php

header("location: home");
exit;

?>